﻿const XLSX = require("xlsx");
const path = require("path");
const fs = require("fs");
const { DateTime } = require("luxon");

const RATES = {
  "Jose": 25,
  "JosÃ©": 25,
  "Myer": 20,
  "Damian": 30,
  "Chris": 30
};

function isWeekend(dateISO) {
  const dt = DateTime.fromISO(dateISO);
  return dt.weekday === 6 || dt.weekday === 7;
}

async function generateWorkerExcel(allEntries, workerName, weekStartISO, opts = {}) {
  const outDir = opts.outDir || path.join(__dirname, "..", "output");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const wb = XLSX.utils.book_new();
  const weekStart = DateTime.fromISO(weekStartISO);
  const weekEnd = weekStart.plus({ days: 7 });
  const rows = [["Date","Address","Unit #","Start Time","End Time","Total Hours","Worker","Worker Pay","Description","Materials Cost"]];

  const entries = allEntries.filter(e => (e.worker || "").toLowerCase() === (workerName || "").toLowerCase())
    .filter(e => {
      const dt = DateTime.fromISO(e.date);
      return dt >= weekStart && dt < weekEnd;
    });

  for (const e of entries) {
    const dateISO = DateTime.fromISO(e.date).toISODate();
    const unit = e.unit || "";
    const start = e.start || "";
    const end = e.end || "";
    const totalHours = Number(e.totalHours || 0);
    const rate = RATES[workerName] || RATES[e.worker] || 0;
    let pay = totalHours * rate;
    const wname = workerName;
    if (isWeekend(dateISO) && (["Jose","JosÃ©","Damian","Chris"].includes(wname))) {
      pay = totalHours * rate * 1.5;
    }
    const materials = e.materials ? Number(e.materials) : "";
    const desc = (e.notes || "").replace(/\s+/g," ").trim().slice(0,140);
    rows.push([dateISO, e.address || "", unit, start, end, roundDecimal(totalHours,2), workerName, roundDecimal(pay,2), desc, materials]);
  }

  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws["!cols"] = rows[0].map(h => ({ wch: Math.min(Math.max(h.length + 6, 10), 40) }));
  XLSX.utils.book_append_sheet(wb, ws, "Timesheet");
  const filename = `${workerName.replace(/\s+/g,"_")}_week_${weekStartISO}.xlsx`;
  const outPath = path.join(outDir, filename);
  XLSX.writeFile(wb, outPath);
  return outPath;
}

function roundDecimal(n, places) {
  return Math.round(n * Math.pow(10, places)) / Math.pow(10, places);
}

module.exports = { generateWorkerExcel };
