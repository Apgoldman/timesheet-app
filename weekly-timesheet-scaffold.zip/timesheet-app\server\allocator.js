﻿const { DateTime } = require("luxon");
const { Client } = require("@googlemaps/google-maps-services-js");

async function allocateTimesAcrossAddresses(entries, googleMapsApiKey = null, opts = {}) {
  const grouped = {};
  for (const e of entries) {
    const wk = `${e.worker}||${e.date}`;
    if (!grouped[wk]) grouped[wk] = [];
    grouped[wk].push(Object.assign({}, e));
  }

  const out = [];
  for (const key of Object.keys(grouped)) {
    const rows = grouped[key];
    const needsAllocation = rows.some(r => !r.start && !r.end && r.totalHours);
    if (!needsAllocation) {
      for (const r of rows) out.push(r);
      continue;
    }

    let weights = rows.map(r => 1.0);
    for (let i = 0; i < rows.length; i++) {
      const notes = (rows[i].notes || "").toLowerCase();
      if (notes.match(/install|replace|reinstallation|major|complete|cartridge|repair/)) weights[i] += 1.0;
      if (notes.match(/clean|check|inspect|sweep|mop|salt/)) weights[i] += 0.5;
      weights[i] += Math.min(1.0, (rows[i].notes || "").length / 120.0);
    }

    if (googleMapsApiKey) {
      try {
        const client = new Client({});
        const origins = [rows[0].address];
        const destinations = rows.map(r => r.address);
        const resp = await client.distancematrix({ params: { origins, destinations, key: googleMapsApiKey } });
        const elements = resp.data.rows[0].elements;
        for (let i = 0; i < elements.length; i++) {
          const el = elements[i];
          if (el && el.duration && el.duration.value) {
            weights[i] += Math.min(2, el.duration.value / 1800);
          }
        }
      } catch (err) {
        console.warn("Google Maps request failed, falling back to keyword weighting", err.message);
      }
    }

    const totalHours = rows.reduce((s, r) => s + (r.totalHours || 0), 0) || (rows[0].totalHours || 0);
    const sumW = weights.reduce((s, x) => s + x, 0);
    const dayTotal = totalHours > 0 ? totalHours : 8;
    const allocations = weights.map(w => (w / sumW) * dayTotal);

    const tz = opts.tz || "America/New_York";
    let currentStart = DateTime.fromObject({ hour: 9, minute: 0 }, { zone: tz });
    for (let i = 0; i < rows.length; i++) {
      const hours = Math.round(allocations[i] * 4) / 4;
      const minutes = Math.round(hours * 60);
      const start = currentStart;
      const end = start.plus({ minutes });
      rows[i].start = start.toFormat("HH:mm");
      rows[i].end = end.toFormat("HH:mm");
      rows[i].totalHours = minutes / 60;
      currentStart = end.plus({ minutes: 15 });
      out.push(rows[i]);
    }
  }
  return out;
}

module.exports = { allocateTimesAcrossAddresses };
